#!/usr/bin/env bash
# System setup shared by install.sh and the statsmagic .deb (postinst). Not run by people.
#   setup-system.sh --operator <login> [--api-base https://host]
# Without --api-base it keeps the one in /etc/statsmagic/service.json (or uses the website's).
# To change which login opens SM² after `apt install statsmagic`:
#   sudo /usr/lib/statsmagic/setup-system.sh --operator <login>
# Needs /opt/statsmagic/{sm-host,sm2} and the statsmagic-host.service unit in place already.
# Creates the 'statsmagic' account, writes /etc/statsmagic, the service's folders and the
# sm2 / sm2-setup commands, then enables and starts the service. Pairing and servers stay.
set -euo pipefail

SERVICE_USER=statsmagic
operator=""
API_BASE=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --operator) operator="${2:-}"; shift 2 ;;
    --api-base) API_BASE="${2:-}"; shift 2 ;;
    *) echo "setup-system.sh: unknown option $1" >&2; exit 1 ;;
  esac
done

fail() { echo "statsmagic: $*" >&2; exit 1; }
if [[ -z "$API_BASE" && -f /etc/statsmagic/service.json ]]; then
  API_BASE="$(sed -n 's/.*"api_base": "\([^"]*\)".*/\1/p' /etc/statsmagic/service.json)"
fi
API_BASE="${API_BASE:-https://api-production-8bb79.up.railway.app}"
[[ "$(id -u)" == 0 ]] || fail "needs root"
[[ "$API_BASE" =~ ^https://[A-Za-z0-9.-]+(:[0-9]{1,5})?$ ]] || fail "--api-base must be https://host with no path"
[[ -n "$operator" ]] || fail "say whose login opens SM²: --operator <login>"
operator_uid="$(id -u "$operator" 2>/dev/null)" || fail "no login named '$operator'"
[[ "$operator_uid" != 0 ]] || fail "SM² is opened from a normal login, not root: --operator <login>"

# 1. The service account (no password, no login shell).
if ! id -u "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --home-dir /var/lib/statsmagic --no-create-home --shell /usr/sbin/nologin \
    --comment "Stats Magic Host" "$SERVICE_USER"
fi
service_uid="$(id -u "$SERVICE_USER")"
[[ "$service_uid" != "$operator_uid" ]] || fail "the operator cannot be the service account"

# 2. Fixed configuration: root-owned and read-only, so the host cannot change who it trusts.
install -d -o root -g root -m 0755 /etc/statsmagic
umask 022
printf '{"state_path": "/var/lib/statsmagic/host-agent/device.json", "api_base": "%s"}\n' "$API_BASE" \
  > /etc/statsmagic/service.json
printf '{"operator_uid": %s, "service_uid": %s}\n' "$operator_uid" "$service_uid" > /etc/statsmagic/ipc.json
chown root:root /etc/statsmagic/service.json /etc/statsmagic/ipc.json
chmod 0644 /etc/statsmagic/service.json /etc/statsmagic/ipc.json

# 3. The service's own folders. Existing pairing and servers are kept.
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0750 /var/lib/statsmagic /var/lib/statsmagic/cs2-host
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0700 /var/lib/statsmagic/host-agent \
  /var/lib/statsmagic/host-agent/local-control-receipts
state=/var/lib/statsmagic/host-agent/device.json
if [[ ! -e "$state" ]]; then
  ( umask 077
    printf '{"api_base": "%s", "install_root": "/var/lib/statsmagic/cs2-host"}\n' "$API_BASE" > "$state.tmp" )
  chown "$SERVICE_USER:$SERVICE_USER" "$state.tmp"
  mv "$state.tmp" "$state"
fi
[[ -f "$state" && ! -L "$state" ]] || fail "$state is not a plain file; leave it for support"

# 4. Commands on PATH. The uids are fixed here, never read from the environment.
cat > /usr/local/bin/sm2 <<EOF
#!/bin/sh
# Opens SM², the Stats Magic host manager. Written by Stats Magic setup.
exec /opt/statsmagic/sm2/sm-squared --live-experimental --controls-experimental --operator-uid $operator_uid --service-uid $service_uid "\$@"
EOF
cat > /usr/local/bin/sm2-setup <<'EOF'
#!/bin/sh
# Pair, unpair, start or stop the Stats Magic host: sudo sm2-setup pair
exec /opt/statsmagic/sm-host/sm-host linux-setup "$@"
EOF
chown root:root /usr/local/bin/sm2 /usr/local/bin/sm2-setup
chmod 0755 /usr/local/bin/sm2 /usr/local/bin/sm2-setup

# 5. The systemd service, started now and at every boot.
# Without a running systemd (a container or chroot) it is only enabled for the next boot.
running=false
if [[ -d /run/systemd/system ]]; then
  systemctl daemon-reload
  systemctl enable statsmagic-host.service
  # Restart, not just start: a running host keeps the ipc.json it read at start, so a changed
  # operator only takes effect after a restart (its servers restart with it).
  systemctl restart statsmagic-host.service
  running=true
else
  systemctl enable statsmagic-host.service
fi

# 6. CS2's SteamCMD is 32-bit: say what to install if its libraries are missing.
if [[ ! -e /lib/ld-linux.so.2 && ! -e /usr/lib32/ld-linux.so.2 ]]; then
  echo
  echo "CS2 needs 32-bit libraries before its first install. On Ubuntu or Debian run:"
  echo "  sudo apt update && sudo apt install -y lib32gcc-s1"
fi

# 7. Each CS2 install takes about 60 GB: say so before the first download fails.
free_gb="$(df -P --block-size=1G /var/lib/statsmagic/cs2-host | awk 'NR==2 {print $4}')"
if [[ "$free_gb" =~ ^[0-9]+$ ]] && (( free_gb < 70 )); then
  echo
  echo "Only ${free_gb} GB is free for CS2 in /var/lib/statsmagic/cs2-host; one CS2 install needs about 60 GB."
  echo "Give that folder a bigger disk before adding a server."
fi

echo
if $running; then echo "The host is running."; else echo "The host starts at the next boot."; fi
echo "Open SM² as $operator:   sm2"
grep -q '"device_token"' "$state" 2>/dev/null || echo "Pair with the website:  sudo sm2-setup pair"
echo "Open the game ports yourself, for example: sudo ufw allow 27015:27016/tcp && sudo ufw allow 27015:27016/udp"
